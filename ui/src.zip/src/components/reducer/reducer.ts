import { combineReducers } from "redux";
import blogs from "./blogs";

export default combineReducers({
  blogs,
});
